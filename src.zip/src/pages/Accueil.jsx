import { useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import ProductCloths from "../components/cloths/ProductCloths";
import Bouton from "../components/bouton/Bouton";
// import useCompteur from "../hooks/useCompteur";
import "./Accueil.module.css";

const Accueil = () => {
  const [products, setProducts] = useState([]);
  const { count, handleIncrement, handleDecrement, handleReset } = useCompteur(0);
  const navigate = useNavigate();

  useEffect(() => {
    axios.get("http://localhost:5000/api/products")
      .then(response => setProducts(response.data))
      .catch(error => console.error("Erreur :", error));
  }, []);

  const handleNavigate = (id) => {
    navigate(`/detail/${id}`);
  };

  return (
    <>
      <h1>Bienvenue à l'Ipssi Store</h1>

      <div className="cloths-disponibles">
        {products.map((product) => (
          <div key={product._id}>
            <ProductCloths {...product} />
            <Bouton label="Voir Détails" onClick={() => handleNavigate(product._id)} />
            <Bouton label="Quitter" onClick={() => handleNavigate(product._id)} />
            <Bouton label="Suivant" onClick={() => handleNavigate(product._id)} />
          </div>
        ))}
      </div>

      <h2>Quantité : {count}</h2>
      <Bouton label="+ 1" onClick={handleIncrement} />
      <Bouton label="- 1" onClick={handleDecrement} />
      <Bouton label="Reset" onClick={handleReset} />
    </>
  );
};

export default Accueil;
