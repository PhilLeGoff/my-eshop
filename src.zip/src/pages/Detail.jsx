import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import axios from "axios";
import "./Detail.module.css";

const Detail = () => {
  const { id } = useParams();
  const [product, setProduct] = useState(null);

  useEffect(() => {
    axios.get(`http://localhost:5000/api/products/${id}`)
      .then(response => setProduct(response.data))
      .catch(error => console.error("Erreur :", error));
  }, [id]);

  if (!product) return <p>Chargement...</p>;

  return (
    <div className="detail-container">
      <h1>{product.name}</h1>
      <img src={product.image} alt={product.name} className="product-image" />
      <p>{product.description}</p>
      <h2>{product.price}€</h2>
      <Bouton label="Ajouter au panier" onClick={() => alert("Ajouté au panier !")} />
    </div>
  );
};

export default Detail;
