import React from "react";
import "./Bouton.module.css";

const Bouton = ({ label, onClick }) => {
  return (
    <button className="bouton" onClick={onClick}>
      {label}
    </button>
  );
};

export default Bouton;
